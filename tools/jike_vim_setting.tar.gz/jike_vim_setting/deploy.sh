#!/bin/bash
# Copyright 2012 Jike Inc. All Rights Reserved.
# Date  : 2012-08-15 14:12:49
# File  : deploy.sh

sudo cp -r . ~/
