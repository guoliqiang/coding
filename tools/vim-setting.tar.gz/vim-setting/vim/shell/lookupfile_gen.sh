#!/bin/bash
# Copyright 2014 Liqiang Guo. All Rights Reserved.
# Author: Liqiang Guo (guoliqiang2006@gmail.com)
# Date  : 2014-10-25 11:14:44
# File  : lookupfile_gen.sh
# Brief : generate tag file for lookupfile plugin

rm -rf /tmp/filenametags
cur=`pwd`
echo -e "!_TAG_FILE_SORTED\t2\t/2=foldcase/" > /tmp/filenametags
find $cur -not -regex '.*\.\(png\|gif\)' -type f -printf "%f\t%p\t1\n" | \
sort -f >> /tmp/filenametags

