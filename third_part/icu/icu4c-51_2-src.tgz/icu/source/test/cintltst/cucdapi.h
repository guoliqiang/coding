/********************************************************************
 * COPYRIGHT:
 * Copyright (c) 2003-2013, International Business Machines Corporation and
 * others. All Rights Reserved.
 ********************************************************************/

void TestUScriptCodeAPI(void);
void TestHasScript(void);
void TestGetScriptExtensions(void);
void TestScriptMetadataAPI(void);
void TestBinaryValues(void);
