
#define MESSAGE "hello objective-c++"
