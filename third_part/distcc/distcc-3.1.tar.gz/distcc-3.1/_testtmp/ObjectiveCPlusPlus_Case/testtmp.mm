
#import <iostream>
#import "testhdr.h"

/* TODO: use Objective-C features. */

int main(void) {
    std::cout << MESSAGE << std::endl;
    return 0;
}
