
#include "types.h"    /* Should resolve to /usr/incude/sys/types.h. */
#include <stdio.h>
#include "testhdr.h"
int main(void) {
    puts(HELLO_WORLD);
    return 0;
}
