#define FOO 3
#if FOO < 10
small foo!
#else
large foo!
#endif
/* comment ca? */
