
#import <stdio.h>
#import "testhdr.h"

/* TODO: use objective-c features. */

int main(void) {
    puts(MESSAGE);
    return 0;
}
