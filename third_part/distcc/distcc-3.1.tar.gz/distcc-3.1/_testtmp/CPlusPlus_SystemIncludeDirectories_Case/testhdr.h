
#define MESSAGE "hello world"
