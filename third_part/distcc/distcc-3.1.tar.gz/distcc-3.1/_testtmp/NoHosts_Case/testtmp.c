
#include <stdio.h>
#include "testhdr.h"
int main(void) {
    puts(HELLO_WORLD);
    return 0;
}
