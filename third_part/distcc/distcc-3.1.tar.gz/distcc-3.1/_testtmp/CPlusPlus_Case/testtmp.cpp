
#import <iostream>
#import "testhdr.h"

int main(void) {
    std::cout << MESSAGE << std::endl;
    return 0;
}
