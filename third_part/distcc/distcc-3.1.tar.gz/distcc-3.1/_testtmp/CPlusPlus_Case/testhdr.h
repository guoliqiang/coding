
#define MESSAGE "hello c++"
