#include <stdio.h>

int main(void) {
   extern const char *msg;
   puts(msg);
   return 0;
}
