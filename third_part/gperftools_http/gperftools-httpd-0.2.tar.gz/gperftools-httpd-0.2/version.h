/* version.h - version defines for thttpd and libhttpd */

#ifndef _VERSION_H_
#define _VERSION_H_

#define SERVER_SOFTWARE "gperftools-httpd/0.2 2006/10/18"
#define SERVER_ADDRESS "http://code.google.com/p/gperftools-httpd/"

#endif /* _VERSION_H_ */
