/* pathdef.c */
/* This file is automatically created by Makefile
 * DO NOT EDIT!  Change Makefile only. */
#include "vim.h"
char_u *default_vim_dir = (char_u *)"/home/guoliqiang/git-coding/coding/third_part/vim7.4/share/vim";
char_u *default_vimruntime_dir = (char_u *)"";
char_u *all_cflags = (char_u *)"gcc -c -I. -Iproto -DHAVE_CONFIG_H     -g -O2 -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=1      ";
char_u *all_lflags = (char_u *)"gcc   -L/usr/local/lib -Wl,--as-needed -o vim        -lm -lncurses -lnsl           ";
char_u *compiled_user = (char_u *)"guoliqiang";
char_u *compiled_sys = (char_u *)"ubuntu";
