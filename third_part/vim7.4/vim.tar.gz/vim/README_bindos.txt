README_bindos.txt for version 7.4 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_dos.txt" for installation instructions for MS-DOS and MS-Windows.
These files are in the runtime archive (vim74rt.zip).


There are several binary distributions of Vim for the PC.  You would normally
pick only one of them, but it's also possible to install several.
These ones are available (the version number may differ):
	vim74w32.zip	Windows 95/98/NT/etc. console version
	gvim74.zip	Windows 95/98/NT/etc. GUI version
	gvim74ole.zip	Windows 95/98/NT/etc. GUI version with OLE

You MUST also get the runtime archive (vim74rt.zip).
The sources are also available (vim74src.zip).
