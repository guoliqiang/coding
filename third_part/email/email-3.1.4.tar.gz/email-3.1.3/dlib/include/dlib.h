#ifndef __DLIB_H
#define __DLIB_H 1

typedef enum { false, true } bool;
enum { ERROR, SUCCESS, DLIB_MAXBUF = 1024 };

#define DLIB_VERSION "0.1b"

#endif

